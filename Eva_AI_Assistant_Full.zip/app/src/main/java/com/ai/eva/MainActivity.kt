package com.ai.eva

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var chatContainer: LinearLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var chipsBar: LinearLayout
    private lateinit var inputMessage: EditText

    private val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        chatContainer = findViewById(R.id.chatContainer)
        chatScroll = findViewById(R.id.chatScroll)
        chipsBar = findViewById(R.id.chipsBar)
        inputMessage = findViewById(R.id.inputMessage)

        findViewById<ImageButton>(R.id.btnSend).setOnClickListener { sendCurrentInput() }
        findViewById<ImageButton>(R.id.btnMic).setOnClickListener {
            // Placeholder: wire this up to SpeechRecognizer / RecognizerIntent when ready.
            inputMessage.setText("Eva, tum kaisi ho?")
            sendCurrentInput()
        }
        findViewById<TextView>(R.id.btnPro).setOnClickListener { showProModal() }

        inputMessage.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND || actionId == EditorInfo.IME_ACTION_DONE) {
                sendCurrentInput()
                true
            } else {
                false
            }
        }

        buildChips()

        // Opening greeting
        appendMessage(
            "Namaste! Main Eva hoon, aapki personal AI companion! Aaj aapka mood kaisa hai? " +
                "Kuch meethi baat karni hai ya koi kaam karna hai? 🥰❤️",
            isEva = true
        )
    }

    private fun buildChips() {
        val chips = listOf(
            "📸 Alam ki Photo" to "Alam ki photo dikhao",
            "👑 Owner Details" to "Aapka malik kaun hai?",
            "💬 WhatsApp Kholo" to "WhatsApp kholo",
            "🚀 App Kaise Banayein" to "Mujhe bhi tumhare jaisa app banana hai"
        )
        for ((label, query) in chips) {
            val chip = TextView(this).apply {
                text = label
                setTextColor(Color.parseColor("#E1BEE7"))
                setPadding(28, 14, 28, 14)
                textSize = 12f
                background = androidx.core.content.ContextCompat.getDrawable(
                    context, android.R.drawable.btn_default
                )
                setOnClickListener {
                    inputMessage.setText(query)
                    sendCurrentInput()
                }
            }
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.marginEnd = 16
            chipsBar.addView(chip, params)
        }
    }

    private fun sendCurrentInput() {
        val text = inputMessage.text.toString().trim()
        if (text.isEmpty()) return
        appendMessage(text, isEva = false)
        inputMessage.setText("")

        val reply = EvaBrain.getResponse(text)

        chatContainer.postDelayed({
            appendMessage(reply.message, isEva = true)
            if (reply.showCreatorCard) appendCreatorCard()
            if (reply.showProModal) showProModal()
            reply.openApp?.let { pkg -> launchApp(pkg) }
        }, 400)
    }

    private fun appendMessage(text: String, isEva: Boolean) {
        val bubble = TextView(this).apply {
            this.text = "$text\n\n${timeFormat.format(Date())}"
            setPadding(32, 24, 32, 24)
            setTextColor(if (isEva) resources.getColor(R.color.text_white, theme) else Color.WHITE)
            textSize = 14.5f
            background = androidx.core.content.ContextCompat.getDrawable(
                context,
                if (isEva) R.drawable.ic_launcher_background else android.R.drawable.btn_default
            )
        }
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.bottomMargin = 20
        params.gravity = if (isEva) Gravity.START else Gravity.END
        chatContainer.addView(bubble, params)
        chatScroll.post { chatScroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun appendCreatorCard() {
        val card = TextView(this).apply {
            text = "Alam (Creator & Owner)\n@alam__6786__ • Makhdumpur, Nawada (Bihar)"
            setTextColor(Color.WHITE)
            setPadding(28, 24, 28, 24)
            background = androidx.core.content.ContextCompat.getDrawable(
                context, R.drawable.ic_launcher_background
            )
        }
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.gravity = Gravity.START
        params.bottomMargin = 20
        chatContainer.addView(card, params)
        chatScroll.post { chatScroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun showProModal() {
        AlertDialog.Builder(this)
            .setTitle("👑 EVA PRO ACCESS")
            .setMessage("Unlimited Voice Calling, Romantic Conversations aur AI Masterclass!\n\n🔥 ₹350 for 2 Months")
            .setPositiveButton("Pay with UPI") { dialog, _ ->
                // Wire up your real UPI/payment flow here.
                dialog.dismiss()
            }
            .setNegativeButton("Close") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    /** Tries the accessibility service first, falls back to a normal launch Intent. */
    private fun launchApp(packageName: String) {
        val opened = EvaAccessibilityService.instance?.openApp(packageName) ?: false
        if (opened) return

        if (!EvaAccessibilityService.isEnabled(this)) {
            promptEnableAccessibility()
        }

        try {
            val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                startActivity(launchIntent)
            } else {
                appendMessage("Ye app aapke phone me install nahi hai. 🙁", isEva = true)
            }
        } catch (e: PackageManager.NameNotFoundException) {
            appendMessage("Ye app nahi mil paayi. 🙁", isEva = true)
        }
    }

    private fun promptEnableAccessibility() {
        AlertDialog.Builder(this)
            .setTitle("Accessibility Permission")
            .setMessage("Voice command se app kholne ke liye Eva Accessibility Service on karein.")
            .setPositiveButton("Open Settings") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton("Later", null)
            .show()
    }
}
