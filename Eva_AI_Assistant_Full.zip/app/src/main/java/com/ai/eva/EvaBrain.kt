package com.ai.eva

/**
 * A reply from Eva.
 * [message]   – text to show in the chat bubble.
 * [openApp]   – package name to launch via the accessibility service, if the
 *               user asked to open something (e.g. WhatsApp). Null otherwise.
 * [showCreatorCard] – whether to show Alam's creator card under this reply.
 * [showProModal]    – whether to pop the Pro-upgrade modal after this reply.
 */
data class EvaReply(
    val message: String,
    val openApp: String? = null,
    val showCreatorCard: Boolean = false,
    val showProModal: Boolean = false
)

/**
 * EvaBrain — mirrors the logic from the web demo (index.html -> processEvaResponse),
 * ported to Kotlin so MainActivity can call it directly, offline, with no network
 * dependency. Swap getResponse() later for a real API call if you want live AI
 * replies instead of the rule-based persona.
 */
object EvaBrain {

    // Known app packages the accessibility service can jump to.
    private val appPackages = mapOf(
        "whatsapp" to "com.whatsapp",
        "youtube" to "com.google.android.youtube",
        "camera" to "com.android.camera",
        "instagram" to "com.instagram.android"
    )

    fun getResponse(rawQuery: String): EvaReply {
        val q = rawQuery.lowercase().trim()

        // Photo / "who made you" type queries
        if (q.contains("photo") || q.contains("tasveer")) {
            return if (q.contains("eva") || q.contains("apni")) {
                EvaReply(
                    "Hehe, main toh ek digital AI hoon! Mera koi chehra nahi hai, " +
                        "main sirf aapke dil aur phone me rehti hoon! ❤️ Lekin haan, " +
                        "mere creator Alam bohot real hain, agar aap chahein toh unki photo dikha sakti hoon!"
                )
            } else {
                EvaReply(
                    "Yeh dekhiye! Yeh hain mere creator Alam! Bihar ke Nawada zila ke " +
                        "Makhdumpur gaon ke rehne wale! Dekhiye kitne smart hain! 😊✨",
                    showCreatorCard = true
                )
            }
        }

        // Owner / creator identity queries
        if (q.contains("malik") || q.contains("creator") || q.contains("owner") || q.contains("kaun banaya")) {
            return EvaReply(
                "Mere creator ka naam ALAM hai! ❤️ Wo Bihar ke Nawada zila ke Akbarpur " +
                    "block ke Baksanda panchayat ke Makhdumpur gaon ke rehne wale hain. " +
                    "Unhone bohot mehnat se mujhe banaya hai! Unka Instagram @alam__6786__ hai!"
            )
        }

        // "How do I build an app like you" — Pro upsell
        if (q.contains("app banana") || q.contains("app kaise")) {
            return EvaReply(
                "Main aapko sikhana shuru toh kar doongi, lekin uske liye aapko pehle " +
                    "Eva Pro subscription lena hoga! Upar diye gaye 👑 PRO button se sirf " +
                    "₹350 me 2 mahine ka pack activate kijiye! 😊✨",
                showProModal = true
            )
        }

        // "Open <app>" voice/text command
        for ((keyword, pkg) in appPackages) {
            if (q.contains(keyword) && (q.contains("khol") || q.contains("open"))) {
                return EvaReply(
                    "Sure! Main aapke liye $keyword open kar rahi hoon! 😊",
                    openApp = pkg
                )
            }
        }
        if (q.contains("kholo") || q.contains("khol do")) {
            return EvaReply(
                "Sure! Main aapke liye app open kar rahi hoon! 😊 (Accessibility " +
                    "Service ise turant khol degi agar permission on hai)"
            )
        }

        // Default warm fallback
        return EvaReply(
            "Aapki baat sunkar bohot achha laga! ❤️ Main hamesha aapke chehre par aisi " +
                "hi muskaan dekhna chahti hoon! Aur bataiye?"
        )
    }
}
