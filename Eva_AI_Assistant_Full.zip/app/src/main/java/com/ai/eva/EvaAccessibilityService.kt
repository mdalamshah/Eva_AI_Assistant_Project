package com.ai.eva

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.text.TextUtils
import android.view.accessibility.AccessibilityEvent

/**
 * EvaAccessibilityService — required so Eva can bring other apps to the
 * foreground on command ("WhatsApp kholo"). Declared in AndroidManifest.xml
 * and configured by res/xml/accessibility_service_config.xml.
 */
class EvaAccessibilityService : AccessibilityService() {

    companion object {
        // MainActivity checks this to know whether it can ask the service
        // to launch an app right now, or needs to fall back to a normal Intent.
        var instance: EvaAccessibilityService? = null
            private set

        fun isEnabled(context: Context): Boolean {
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val expected = "${context.packageName}/${EvaAccessibilityService::class.java.name}"
            if (TextUtils.isEmpty(enabledServices)) return false
            return enabledServices.split(":").any { it.equals(expected, ignoreCase = true) }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    /** Launches an installed app by package name. Returns true if it was found and started. */
    fun openApp(packageName: String): Boolean {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName) ?: return false
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launchIntent)
        return true
    }

    // Required override — we don't need to react to every window event right now,
    // but the service must implement this to receive the accessibility callbacks
    // declared in accessibility_service_config.xml.
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally empty for now. Hook window-state changes here later
        // if you want Eva to read screen content, not just launch apps.
    }

    override fun onInterrupt() {
        // No ongoing action to cancel.
    }
}
